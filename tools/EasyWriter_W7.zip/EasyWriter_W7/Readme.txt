NOVATEK EasyWriter Released Version
Copyright (c) 1997-2010 NOVATEK MicroElectronics Corp.
Website: HTTP://www.novatek.com.tw/
Lastest Released Date: Mar 11, 2010

Files 
-----
writer.exe  - Execute program file.
ntport.dll  - EasyWriter runtime DLL. (Windows 95/98/ME)
zntport.sys - EasyWriter system file (Windows NT/2000/XP) \\windows\system32\drivers\ 
readme.txt  - This readme file
devctrl.dll - EasyUSB runtime DLL

Description
-----------
EasyWriter is using to programming NOVATEK flash type MCUs such as NT68F63,NT68F65,NT68F631..etc.
EasyWriter supports both administrator and non-administrator accont, but "administrator privileges
are required to install easywriter on Windows NT/2000/XP".

Functions
----------
1.[Load File Button]
	Load Hex/Bin file to buffer.
2.[ISP ON Buttion]
	Detect NVT's MCU type & Enter ISP Mode.
3.[ISP OFF Button]
	Exit ISP mode & reset MCU.
4.[View Hex Button]:
	View Buffer data in HEX format.
5.[Auto Button]
	combo commands:
	1.Reload HEX/BIN file.
	2.ISP on.
	3.Chip Erase.
	4.Program.
	5.ISP off.
6.[Program Button]
	Write buffer data to MCU(Flash ROM) via DDC channel.
	Skip blank pages automatically.
7.[Erase Button]
	Whole chip Flash memory erase.
8.[Get CheckSum]
	Get Flash memory checksum.

History
-------
2010.0518
	Support AMIC unprotect
	Support PMC Safe Guard
	Support NT68669,NT68660,NT68650,NT68676 Scalers.
	Support Autodetect ECKS identify.
	Support Autodetect Direct FE2P Mode.
	Support PMC LD type flash.
2010.311 
	Support Vesta/W7 (Optional)
	Support FTDI Chip
	Support FE2P,CHECKSUM auto detect
	Fixed some minor bugs.	
4.5	New FE2P Block enabled select.
	New hex code Special Text.
4.4	Fix NT68167 Program speed limite issue.
	ISP on keep present status in NT68673,NT68167
4.3	Support EON,AMIC flash
	user define Flash WP control pins.
	New EDID program mode
4.2	Support new version NT68673,NT68167
4.1	Support new NT68167,NT68667,NT68673 Scalers
	Cancel MCU select menu(auto detect)
	Graphic View Hex form
	Fix many bugs.
	FE2P code overlap warning
	Getcheck sum bypass FE2P area
	Recent file list
	Auto detect external Flash type
	SPI WP pin control
	SPI Flash Block Protect/unProtect control
	USB Speed Limit control
4.0 	new UI with Skin change
	new MCU type select menu(hot key 'S')
	support NT68670-256k,NT68F631B,NT68665-128J MCUs
	support FE2P block Erase
3.0 	Jig type selectable.
	User defined Jig pinout.
	Support 256k 4,8 Banks format.
	EasyUSB Jig support. (for windows 2000/XP only)
2.4 	Support NT68670-128k MCU
	new features for NT68670
	1.Faster programming speed.
	2.faster get checksum speed.
	Modified auto detect IIC speed.
2.3	Support NT68663/NT68623/NT68621/NT68665 MCUs
	New look
	Fix long path or long file name issue
	Show file access time and last update time in memo area
2.10	Add an nt68f633g 64k rom size selection
	Add hot keys 
2.09	Add get checksum function.
2.08	Support binary file format.
2.07	Support 2 bank *.H00,*.H01 format.
2.06	Fix 128K checksum issue.
2.05	Add select MCU type funtion.
2.04	Auto detect IIC speed at first time execute easywriter.
	Add filled Check Sum.
	Add creat Check Sum File funcion.
2.03	Change progress bar style.
2.02	Fix auto reload bank switch file issue.
2.01	Fix windows nt/2000/xp auto detect incorrect issue.
2.0	Different looks than version 1.x.
	Add rolling information window.
	Add auto detect CPU speed.
	New information file format. (ezwriter.ini)
	Last time directory memory.
	Support higher CPU speed.
	Support more MCU types.
	Fix load file bug.
	Fix hold low SCL bug when communication failure.
1.4	Accept bank switch Hex file *.H01~.H03.
	Convert *.H01,H02,H03 to hex file after load *.H01. 
1.3	Fix windows2000 printer port control problem.
1.2	Increase programming speed of NT68f631/NT68f632.
1.1	Add error retry function.
1.0 Initial Version.

FAQs
------------
Q1.Can I run EasyWriter in windows xp?
A1:Yes, EasyWriter V2.xx and above support windows 95 ~ windows xp (include windows 2000/nt).

Q2.Do I need to log as an administrator when I use EasyWriter?
A2:EasyWriter supports both administrator and non-administrator account, but administrator privileges are required to install WasyWriter on Windows NT/2000/XP.

Q3.Programming runs unstable.
A3:Try to modify IIC Speed ."Setup->SetSpeed->Manually adjust" or USB Speed Limit control.

Q4.ISP link fail.
A4:Set printer port address to 378h,EPP/ECP in BIOS setup menu.

Q5.Can I run EasyWriter with EasyUSB jig in Windows 98/ME?
A5:No, EasyUSB do not support Windows 98/ME, please upgrade to windows XP.

